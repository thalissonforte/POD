void bubble_sort(int *vet, int tam);
char menor_arquivos(int arquivo_inicial, int arquivo_final, FILE **arquivos_temporarios, char *nome_arquivo, int tamanho_divisao, int rodada);
char pega_dado(FILE *arquivo);
