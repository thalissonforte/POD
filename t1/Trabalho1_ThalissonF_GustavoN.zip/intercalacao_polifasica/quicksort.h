void quick_sort(int *vet, int tam);
void imprime_vetor(int *vet, int tam);
void imprime_vetor_p(int *vet, int i, int j);
